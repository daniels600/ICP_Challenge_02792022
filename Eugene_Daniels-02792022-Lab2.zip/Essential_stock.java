/**
 * A class that has items, their stock and prices as instances variables
 * and creates an object which is passed into a text file
 * @author Eugene Daniels
 * @version 1.0
 */

import java.io.PrintWriter;
import java.util.*;
import java.io.*;

public class Essential_stock{
    private static final long serialVersionUID = 1L;

    // Instance Varibles
    private String item;
    private long quantity;
    private long price;

    public Essential_stock() {
        this.item = item;
        this.quantity = quantity;
        this.price = price;
    }

    /**
     * Accessor method or getter for the item instance variable
     * @return Item
     */
    public String getItem() {
        return item;
    }

    /**
     * The mutator method to set the item
     * @param item in the essential shop
     */
    public void setItem(String item) {
        this.item = item;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


    public long getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Essential_stock{" +
                "item='" + item + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }

    /**
     * This method doesn't return anything put it takes inputs and adds it
     * to a text file
     */
    public void addItem() {
        Scanner in = new Scanner(System.in);
        PrintWriter printWriter = null;

        try {
            //Note that we are able to append to the file because of the "true" parameter
            printWriter = new PrintWriter(new FileOutputStream("C:\\Users\\Eugene Daniels\\Desktop\\essentials_stock.txt", true));
        }catch(FileNotFoundException fnfe) {
            fnfe.getMessage();
        }
        int count =0;
        try {
            System.out.println("Enter the number of different types of Items on the shelve: \n");
            int x = in.nextInt();

            for(int i=0; i< x;i++) {
                if (count <= x) {
                    System.out.println("Enter the name of Item:");
                    String Item_name = in.next();
                    setItem(Item_name);      // Setting the item to the input taken


                    System.out.println("Enter the quantity of the Item:");
                    int quantity = in.nextInt();
                    setQuantity(quantity);   //Setting the quantity to the input taken


                    System.out.println("Enter the price of the Item: ");
                    int i_price = in.nextInt();
                    setPrice(i_price);       // Setting the price to the input taken


                    // writing the input taken into a text file
                    printWriter.printf("%s %d GHC %d", getItem(), getQuantity(), getPrice());
                    printWriter.println();

                    count++;

                }
            }
            }
            catch(InputMismatchException e){
                System.out.println("Please you have entered the wrong input type");
            }
            printWriter.close();

        }




    /**
     * This method display the content of a text file
     * @param filename  the name of the file to display content from
     * @throws FileNotFoundException this is thrown when the file is not found
     */
    public void Display(String filename) throws FileNotFoundException {
        File file = new File(filename);
        Scanner sc = new Scanner(file); // Using the scanner class to read the text file
        System.out.println("You have these set of Items, their stock and Price:\n");
        while(sc.hasNextLine()){     // checks if there is a next thus true then it prints next
            System.out.println(sc.nextLine()); // This prints the next line characters to the screen
        }

    }



}
