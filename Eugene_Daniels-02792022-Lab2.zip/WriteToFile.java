/**
 * Text Data and Binary Data
 * This program writes attributes of an object into a text file
 * And writes it back into a backup text file
 */

import java.io.*;
import java.util.*;
/**
 * @author David Ebo Adjepon-Yamoah
 * @version 1.0.2
 * Modification by Eugene Daniels
 */
public class WriteToFile implements Serializable {

    /**
     * Serial Version User ID
     */
    private static final long serialVersionUID = 1L;


    /**
     * Constructor
     */
    public WriteToFile() {
        // TODO Auto-generated constructor stub
        Essential_stock products;



    }

    /**
     * Writing Text/String to File using PrintWriter and FileOutputStream
     * Checks for "FileNotFoundException" in the connection to the file
     */
    public void writingTextToFile() throws FileNotFoundException {
        Essential_stock products = new Essential_stock();
        // Scanner in = new Scanner(System.in);
        PrintWriter printWriter = null;

        try {
            //Note that we are able to append to the file because of the "true" parameter
            printWriter = new PrintWriter(new FileOutputStream("C:\\Users\\Eugene Daniels\\Desktop\\essentials_stock.txt", true));
        } catch (FileNotFoundException fnfe) {
            fnfe.getMessage();
        }
        products.addItem();
        try {
            products.Display("C:\\Users\\Eugene Daniels\\Desktop\\essentials_stock.txt");
        }
        catch (FileNotFoundException e){
            System.out.println("Couldn\'t find file to display from");
        }
    }



    /**
     * Writing Binary Data to File
     * @throws IOException
     */
    public void writingBinaryDataToFile() throws IOException {

        BufferedReader input1 = new BufferedReader(new FileReader("C:\\Users\\Eugene Daniels\\Desktop\\essentials_stock.txt"));

        File output1 = new File("C:\\Users\\Eugene Daniels\\Desktop\\backup_essentials_stock.txt");

        FileWriter filewriter = new FileWriter(output1.getAbsoluteFile());
        BufferedWriter outputStream = new BufferedWriter(filewriter);
        String count;
        while((count = input1.readLine()) != null){
            outputStream.write(count);
            outputStream.newLine();
        }
        outputStream.flush();
        outputStream.close();
        input1.close();


    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        Calendar calendar1 = Calendar.getInstance();
        long start_time = calendar1.getTimeInMillis();
        WriteToFile pwd = new WriteToFile();

        try {
            pwd.writingTextToFile();
            pwd.writingBinaryDataToFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Calendar calendar2 = Calendar.getInstance();
        long end_time = calendar2.getTimeInMillis();

        long Elapsed_time = end_time - start_time;

        System.out.println("Elapsed Time is " + Elapsed_time);

    }

}
